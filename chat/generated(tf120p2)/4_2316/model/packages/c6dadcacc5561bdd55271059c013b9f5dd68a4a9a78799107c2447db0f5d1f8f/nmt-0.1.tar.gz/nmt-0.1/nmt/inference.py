# Copyright 2017 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

"""To perform inference on test set given a trained model."""
from __future__ import print_function

import codecs
import time

import tensorflow as tf

from tensorflow.python.ops import lookup_ops

from . import attention_model
from . import gnmt_model
from . import model as nmt_model
from . import model_helper
from .utils import iterator_utils
from .utils import misc_utils as utils
from .utils import nmt_utils
from .utils import vocab_utils

__all__ = ["create_infer_model", "load_inference_hparams", "inference"]


def create_infer_model_m(
    model_creator,
    hparams,
    scope=None):
  (infer_graph, infer_model, infer_src_placeholder,
   infer_batch_size_placeholder, infer_iterator) = (create_infer_model(
       model_creator, hparams, scope))
  return model_helper.InferModel(
      graph=infer_graph,
      model=infer_model,
      src_placeholder=infer_src_placeholder,
      batch_size_placeholder=infer_batch_size_placeholder,
      iterator=infer_iterator)

def create_infer_model(
    model_creator,
    hparams,
    scope=None):
  """Create inference model."""
  infer_graph = tf.Graph()
  src_vocab_file = hparams.src_vocab_file
  tgt_vocab_file = hparams.tgt_vocab_file

  with infer_graph.as_default():
    src_vocab_table = lookup_ops.index_table_from_file(
        src_vocab_file, default_value=vocab_utils.UNK_ID)
    tgt_vocab_table = lookup_ops.index_table_from_file(
        tgt_vocab_file, default_value=vocab_utils.UNK_ID)
    reverse_tgt_vocab_table = lookup_ops.index_to_string_table_from_file(
        tgt_vocab_file, default_value=vocab_utils.UNK)

    infer_src_placeholder = tf.placeholder(shape=[None], dtype=tf.string)
    infer_batch_size_placeholder = tf.placeholder(shape=[], dtype=tf.int64)

    infer_src_dataset = tf.contrib.data.Dataset.from_tensor_slices(
        infer_src_placeholder)
    infer_iterator = iterator_utils.get_infer_iterator(
        infer_src_dataset,
        src_vocab_table,
        batch_size=infer_batch_size_placeholder,
        eos=hparams.eos,
        source_reverse=hparams.source_reverse,
        src_max_len=hparams.src_max_len_infer)
    infer_model = model_creator(
        hparams,
        iterator=infer_iterator,
        mode=tf.contrib.learn.ModeKeys.INFER,
        source_vocab_table=src_vocab_table,
        target_vocab_table=tgt_vocab_table,
        reverse_target_vocab_table=reverse_tgt_vocab_table,
        scope=scope)
  return (infer_graph, infer_model, infer_src_placeholder,
          infer_batch_size_placeholder, infer_iterator)


def load_inference_hparams(model_dir, inference_list=None):
  """Load hparams for inference.

  Args:
    model_dir: directory of trained model.
    inference_list: optional, comma-separated list of sentence ids.

  Returns:
    hparams: A tf.HParams() used for inference.
  """
  hparams = utils.load_hparams(model_dir)
  assert hparams

  # Inference indices
  hparams.inference_indices = None
  if inference_list:
    (hparams.inference_indices) = (
        [int(token)  for token in inference_list.split(",")])

  return hparams


def _decode_inference_indices(model, sess, output_infer,
                              output_infer_summary_prefix,
                              inference_indices,
                              tgt_eos,
                              bpe_delimiter):
  """Decoding only a specific set of sentences."""
  utils.print_out("  decoding to output %s , num sents %d." %
                  (output_infer, len(inference_indices)))
  start_time = time.time()
  with codecs.getreader("utf-8")(
      tf.gfile.GFile(output_infer, mode="w")) as trans_f:
    trans_f.write("")  # Write empty string to ensure file is created.
    for decode_id in inference_indices:
      nmt_outputs, infer_summary = model.decode(sess)

      # get text translation
      assert nmt_outputs.shape[0] == 1
      translation = nmt_utils.get_translation(
          nmt_outputs,
          sent_id=0,
          tgt_eos=tgt_eos,
          bpe_delimiter=bpe_delimiter)

      if infer_summary is not None:  # Attention models
        image_file = output_infer_summary_prefix + str(decode_id) + ".png"
        utils.print_out("  save attention image to %s*" % image_file)
        image_summ = tf.Summary()
        image_summ.ParseFromString(infer_summary)
        with tf.gfile.GFile(image_file, mode="w") as img_f:
          img_f.write(image_summ.value[0].image.encoded_image_string)

      trans_f.write("%s\n" % translation)
      utils.print_out("%s\n" % translation)
  utils.print_time("  done", start_time)


def load_data(inference_input_file, hparams=None):
  """Load inference data."""
  with codecs.getreader("utf-8")(
      tf.gfile.GFile(inference_input_file, mode="rb")) as f:
    inference_data = f.read().splitlines()

  if hparams and hparams.inference_indices:
    inference_data = [inference_data[i] for i in hparams.inference_indices]

  return inference_data


def inference_m(model_dir,
              hparams,
              scope=None):
  """Perform translation."""
  if not hparams.attention:
    model_creator = nmt_model.Model
  elif hparams.attention_architecture == "standard":
    model_creator = attention_model.AttentionModel
  elif hparams.attention_architecture == "gnmt":
    model_creator = gnmt_model.GNMTModel
  else:
    raise ValueError("Unknown model architecture")
  return create_infer_model_m(model_creator, hparams, scope)


def inference(model_dir,
              inference_input_file,
              inference_output_file,
              hparams,
              num_workers=1,
              jobid=0,
              scope=None):
  """Perform translation."""
  if hparams.inference_indices:
    assert num_workers == 1

  if not hparams.attention:
    model_creator = nmt_model.Model
  elif hparams.attention_architecture == "standard":
    model_creator = attention_model.AttentionModel
  elif hparams.attention_architecture == "gnmt":
    model_creator = gnmt_model.GNMTModel
  else:
    raise ValueError("Unknown model architecture")

  if num_workers == 1:
    _single_worker_inference(
        model_creator,
        model_dir,
        inference_input_file,
        inference_output_file,
        hparams,
        scope=scope)
  else:
    _multi_worker_inference(
        model_creator,
        model_dir,
        inference_input_file,
        inference_output_file,
        hparams,
        num_workers=num_workers,
        jobid=jobid,
        scope=scope)


def single_worker_inference_m(infer_model,
                             model_dir,
                             inference_input,
                             hparams,
                             scope=None):
  """Inference with a single worker."""

  # Read data
  infer_data = [inference_input]

  with tf.Session(graph=infer_model.graph, config=utils.get_config_proto()) as sess:
    model_helper.create_or_load_model(
        infer_model.model, model_dir, sess, hparams.out_dir, "infer")
    sess.run(
        infer_model.iterator.initializer,
        feed_dict={
            infer_model.src_placeholder: infer_data,
            infer_model.batch_size_placeholder: hparams.infer_batch_size
        })
    # Decode
    utils.print_out("# Start decoding")
    output_infer = nmt_utils.decode_and_evaluate_m(
        "infer",
        infer_model.model,
        sess,
        metrics=hparams.metrics,
        bpe_delimiter=hparams.bpe_delimiter,
        beam_width=hparams.beam_width,
        tgt_eos=hparams.eos)
    return output_infer

def _single_worker_inference(model_creator,
                             model_dir,
                             inference_input_file,
                             inference_output_file,
                             hparams,
                             scope=None):
  """Inference with a single worker."""
  output_infer = inference_output_file

  # Read data
  infer_data = load_data(inference_input_file, hparams)

  (infer_graph, infer_model, infer_src_placeholder,
   infer_batch_size_placeholder, infer_iterator) = (create_infer_model(
       model_creator, hparams, scope))
  with tf.Session(graph=infer_graph, config=utils.get_config_proto()) as sess:
    model_helper.create_or_load_model(
        infer_model, model_dir, sess, hparams.out_dir, "infer")
    sess.run(
        infer_iterator.initializer,
        feed_dict={
            infer_src_placeholder: infer_data,
            infer_batch_size_placeholder: hparams.infer_batch_size
        })
    # Decode
    utils.print_out("# Start decoding")
    if hparams.inference_indices:
      _decode_inference_indices(
          infer_model,
          sess,
          output_infer=output_infer,
          output_infer_summary_prefix=output_infer,
          inference_indices=hparams.inference_indices,
          tgt_eos=hparams.eos,
          bpe_delimiter=hparams.bpe_delimiter)
    else:
      nmt_utils.decode_and_evaluate(
          "infer",
          infer_model,
          sess,
          output_infer,
          ref_file=None,
          metrics=hparams.metrics,
          bpe_delimiter=hparams.bpe_delimiter,
          beam_width=hparams.beam_width,
          tgt_eos=hparams.eos)


def _multi_worker_inference(model_creator,
                            model_dir,
                            inference_input_file,
                            inference_output_file,
                            hparams,
                            num_workers,
                            jobid,
                            scope=None):
  """Inference using multiple workers."""
  assert num_workers > 1

  final_output_infer = inference_output_file
  output_infer = "%s_%d" % (inference_output_file, jobid)
  output_infer_done = "%s_done_%d" % (inference_output_file, jobid)

  # Read data
  infer_data = load_data(inference_input_file, hparams)

  # Split data to multiple workers
  total_load = len(infer_data)
  load_per_worker = int((total_load - 1) / num_workers) + 1
  start_position = jobid * load_per_worker
  end_position = min(start_position + load_per_worker, total_load)
  infer_data = infer_data[start_position:end_position]

  (infer_graph, infer_model, infer_src_placeholder,
   infer_batch_size_placeholder, infer_iterator) = (create_infer_model(
       model_creator, hparams, scope))

  with tf.Session(graph=infer_graph, config=utils.get_config_proto()) as sess:
    model_helper.create_or_load_model(
        infer_model, model_dir, sess, hparams.out_dir, "infer")
    sess.run(infer_iterator.initializer,
             {
                 infer_src_placeholder: infer_data,
                 infer_batch_size_placeholder: hparams.infer_batch_size
             })
    # Decode
    utils.print_out("# Start decoding")
    nmt_utils.decode_and_evaluate(
        "infer",
        infer_model,
        sess,
        output_infer,
        ref_file=None,
        metrics=hparams.metrics,
        bpe_delimiter=hparams.bpe_delimiter,
        beam_width=hparams.beam_width,
        tgt_eos=hparams.eos)

    # Change file name to indicate the file writting is completed.
    tf.gfile.Rename(output_infer, output_infer_done, overwrite=True)

    # Job 0 is responsible for the clean up.
    if jobid != 0: return

    # Now write all translations
    with codecs.getreader("utf-8")(
        tf.gfile.GFile(final_output_infer, mode="w")) as final_f:
      for worker_id in range(num_workers):
        worker_infer_done = "%s_done_%d" % (inference_output_file, worker_id)
        while not tf.gfile.Exists(worker_infer_done):
          utils.print_out("  waitting job %d to complete." % worker_id)
          time.sleep(10)

        with codecs.getreader("utf-8")(
            tf.gfile.GFile(worker_infer_done, mode="rb")) as f:
          for translation in f:
            final_f.write("%s" % translation)
        tf.gfile.Remove(worker_infer_done)
